﻿// PreAndInDlg1.cpp: 实现文件
//

#include "pch.h"
#include "BinaryTree.h"
#include "PreAndInDlg.h"
#include "afxdialogex.h"
#include <string>
#include<graphics.h>
using namespace std;

// PreAndInDlg1 对话框

IMPLEMENT_DYNAMIC(PreAndInDlg, CDialogEx)

PreAndInDlg::PreAndInDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)

{

}

PreAndInDlg::~PreAndInDlg()
{
}

void PreAndInDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//  DDX_Control(pDX, IDC_EDIT2, PreArray);
	//  DDX_Control(pDX, IDC_EDIT1, InArray);
	//  DDX_Text(pDX, IDC_EDIT2, PreC);
	//  DDX_Text(pDX, IDC_EDIT1, InC);
	DDX_Control(pDX, IDC_EDIT1, Inarray);
	DDX_Control(pDX, IDC_EDIT2, Prearray);
}


BEGIN_MESSAGE_MAP(PreAndInDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &PreAndInDlg::OnBnClickedButtonCreate)
END_MESSAGE_MAP()


// PreAndInDlg1 消息处理程序


void PreAndInDlg::OnBnClickedButtonCreate()
{
	initgraph(1280, 960, INIT_RENDERMANUAL);
	setbkcolor(EGERGB(0x0, 0x0, 0x0));
	ege_enable_aa(true);
	BinTreeNode* root;
	BinaryTree bt;
	CString strPre;
	CString strIn;
	const int MaxSize = 100;
	Prearray.GetWindowTextW(strPre);
	Inarray.GetWindowTextW(strIn);
	string s1 = (CStringA)strPre;
	string s2 = (CStringA)strIn;
	char strpreC1[MaxSize];
	char strInC1[MaxSize];
	strcpy_s(strpreC1, s1.c_str());
	strcpy_s(strInC1, s2.c_str());
	bt.CreateBinTree_PreAndIn(root, strpreC1, strInC1, strPre.GetLength());
	printTree(root, 640, 50);
	getch();
	closegraph();
	// TODO: 在此添加控件通知处理程序代码
}


int PreAndInDlg::printTree(BinTreeNode* bt, int x, int y)
{
	char e[2] = { '\0','\0' };
	int level=0;
	if (bt != NULL)
	{
		level++;
		e[0] = bt->data;
		setcolor(RED);
		circle(x, y, 20);
		setcolor(EGERGB(0x0, 0xFF, 0x0));//ABDFGCEH
																	//BFDGACEH 
		outtextxy(x - 5, y - 10, e);
		getch();
		if (printTree(bt->leftChild, x - (150 - y), y + 40))
			line(x, y, x - (150 - y), y + 40);
		if (printTree(bt->rightChild, x + (150 - y), y + 40))
			line(x, y, x + (150 - y), y + 40);
		return 1;
	}
	return 0;
	// TODO: 在此处添加实现代码.
}
