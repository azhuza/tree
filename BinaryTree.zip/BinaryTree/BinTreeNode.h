#pragma once
#include<iostream>
#include<stdlib.h>
class BinTreeNode
{
public:
	char data;
	BinTreeNode * leftChild, * rightChild,*father;
	BinTreeNode() : leftChild(NULL), rightChild(NULL),father(NULL) {}
	BinTreeNode(char x, BinTreeNode * l = NULL, BinTreeNode* r = NULL, BinTreeNode* f = NULL) : data(x), leftChild(l), rightChild(r),father(f) {}
};

