﻿
// BinaryTree.h: PROJECT_NAME 应用程序的主头文件
//

#pragma once

#ifndef __AFXWIN_H__
#error "在包含此文件之前包含 'pch.h' 以生成 PCH"
#endif

#include "resource.h"		// 主符号
#include<iostream>
#include<stdlib.h>
#include"BinTreeNode.h"
#include <string.h>

// CBinaryTreeApp:
// 有关此类的实现，请参阅 BinaryTree.cpp
//

class CBinaryTreeApp : public CWinApp
{
public:
	CBinaryTreeApp();

	// 重写
public:
	virtual BOOL InitInstance();

	// 实现

	DECLARE_MESSAGE_MAP()
};

extern CBinaryTreeApp theApp;

class BinaryTree
{
public:
	BinaryTree() : root(NULL) {}						 //构造函数
	BinaryTree(char value) : RefValue(value), root(NULL) {} //构造函数
	BinaryTree(BinaryTree& s);						 //复制构造函数
	~BinaryTree() { destroy(root); }					 //析构函数
	BinTreeNode* Parent(BinTreeNode* t)
	{ //返回双亲结点
		return 
			(root == NULL || root == t) ? NULL : Parent(t);
	}
	BinTreeNode* LeftChild(BinTreeNode* t)
	{ //返回左子女
		return (t != NULL) ? t->leftChild : NULL;
	}
	BinTreeNode* RightChild(BinTreeNode* t)
	{ //返回右子女
		return (t != NULL) ? t->rightChild : NULL;
	}

	BinTreeNode* getRoot() const { return root; }
	void CreateBinTree(BinTreeNode*& subTree);
	void CreateBinTree_PreAndIn(BinTreeNode*& subTree,char PreData[], char InData[], int number);
	void CreateBinTree_PosAndIn(BinTreeNode*& subTree, char PosData[], char InData[], int number);

protected:
	BinTreeNode* root; //二叉树的根指针
	char RefValue;			  //数据输入停止标志
	void destroy(BinTreeNode*& subTree);
	void PreOrder(BinTreeNode* subTree, void (*visit)(BinTreeNode* t)); //前序遍历
	int find(char InData[], char e, int s2, int e2)
	{
		for (int i = s2; i <= e2; i++)
		{
			if (InData[i] == e)
				return i;
		}
	}

};
