﻿// PosAndInDlg.cpp: 实现文件
//

#include "pch.h"
#include "BinaryTree.h"
#include "PosAndInDlg.h"
#include "afxdialogex.h"
#include <string>
using namespace std;

// PosAndInDlg 对话框

IMPLEMENT_DYNAMIC(PosAndInDlg, CDialogEx)

PosAndInDlg::PosAndInDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOGposAndin, pParent)
	, Posarray()
	, Inarray()
{

}

PosAndInDlg::~PosAndInDlg()
{
}

void PosAndInDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//  DDX_Text(pDX, IDC_EDIT2, Posarray);
	//  DDX_Text(pDX, IDC_EDIT1, Inarray);
	DDX_Control(pDX, IDC_EDIT1, Inarray);
	DDX_Control(pDX, IDC_EDIT2, Posarray);
}


BEGIN_MESSAGE_MAP(PosAndInDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &PosAndInDlg::OnBnClickedButtonCreate)
END_MESSAGE_MAP()


// PosAndInDlg 消息处理程序


void PosAndInDlg::OnBnClickedButtonCreate()
{
	BinTreeNode* root;
	BinaryTree bt;
	CString strPos;
	CString strIn;
	const int MaxSize = 100;
	Posarray.GetWindowTextW(strPos);
	Inarray.GetWindowTextW(strIn);
	string s1 = (CStringA)strPos;
	string s2 = (CStringA)strIn;
	char strposC1[MaxSize];
	char strInC1[MaxSize];
	strcpy_s(strposC1, s1.c_str());
	strcpy_s(strInC1, s2.c_str());
	bt.CreateBinTree_PosAndIn(root, strposC1, strInC1, strPos.GetLength());
	// TODO: 在此添加控件通知处理程序代码
}
