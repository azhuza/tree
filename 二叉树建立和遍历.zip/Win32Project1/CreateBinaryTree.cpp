/*#include<iostream>
#include<string>
#include<sstream>
#define SHOW_CONSOLE
#include<graphics.h>

using namespace std;
int n = 0;
char arrp[20];
char arrm[20];
char arrl[20];
void cinarryp()
{
	char a;
	string s;
	cin >> s;
	//char* arrp = new char[s.length()];
	stringstream ss;
	ss << s;
	while (ss >> a)
	{
		arrp[n] = a;
		n++;
	}
	ss.clear();

}
void cinarrym()
{
	int n = 0;
	char a;
	string s;
	cin >> s;
	//char* arrm = new char[s.length()];
	stringstream ss;
	ss << s;
	while (ss >> a)
	{
		arrm[n] = a;
		n++;
	}
	ss.clear();
}
void cinarryl()
{
	char a;
	string s;
	cin >> s;
	//char* arrl = new char[s.length()];
	stringstream ss;
	ss << s;
	while (ss >> a)
	{
		arrl[n] = a;
		n++;
	}
	ss.clear();
}
int nflag = 1;
char* whethererror(char* arrp, char* arrm, int size)
{
	if (size == 0) return NULL;
	if (nflag)
	{
		if (!(strlen(arrp) == strlen(arrm)))
		{
			cout << "error!";
			exit(0);
		}
		nflag = 0;
	}
	int flag = 1;
	int r = 0;
	for (int i = 0; i < size; i++)
	{
		if (arrp[0] == arrm[i])
		{
			r = i;
			flag = 0;
			break;
		}
	}
	if (flag)
	{
		cout << "error!" << endl;
		exit(0);
	}
	whethererror(arrp + 1, arrm, r);
	whethererror(arrp + 1 + r, arrm + r + 1, size - 1 - r);
	return NULL;
}

struct bintreenode
{
	char data;//������
	bintreenode* leftchild, *rightchild, *parent;
	bintreenode(char x, bintreenode* p = NULL, bintreenode* q = NULL,
		bintreenode* r = NULL) :data(x), leftchild(p), rightchild(q), parent(r) {};
};
class binarytree
{

public:
	bintreenode* root;
	int flag = 1;//�����
	binarytree();
	bintreenode* creattreep(char* arrp, char* arrm, int size, bintreenode* p, int x0, int y0, int x, int y);//ǰ��������������
	bintreenode* creattreel(char* arrm, char* arrl, int size, bintreenode* p, int x0, int y0, int x, int y);//���������������
	void preoder(bintreenode* p);//ǰ�����
	void inoder(bintreenode* p);//�������
	void postoder(bintreenode* p);//�������
};
binarytree::binarytree()
{
	root = new bintreenode(NULL);
}


bintreenode* binarytree::creattreep(char* arrp, char* arrm, int size, bintreenode* p, int x0, int y0, int x, int y)
{
	if (size == 0)
	{
		return NULL;
	}
	bintreenode* roottemp = new bintreenode(arrp[0], NULL, NULL, p);
	circle(x, y, 25);
	setcolor(EGERGB(0xFF, 0xFF, 0x0));
	Sleep(1 * 1000);
	outtextxy(x, y, roottemp->data);
	Sleep(1 * 1000);
	if (flag) {}
	else line(x0, y0, x, y);
	Sleep(1 * 1000);
	p = roottemp;
	if (flag)
	{
		root = roottemp;
		flag = 0;
	}
	int r = 0;
	for (int i = 0; i < size; i++)
	{
		if (arrm[i] == arrp[0])
		{
			r = i;
			break;
		}
	}

	roottemp->leftchild = creattreep(arrp + 1, arrm, r, p, x, y, x / 2, y * 2);
	roottemp->rightchild = creattreep(arrp + 1 + r, arrm + r + 1, size - 1 - r, p, x, y, (x / 2) * 3, y * 2);

	return roottemp;
}
bintreenode* binarytree::creattreel(char* arrm, char* arrl, int size, bintreenode* p, int x0, int y0, int x, int y)
{
	if (size == 0)
	{
		return NULL;
	}
	bintreenode* roottemp = new bintreenode(arrl[size - 1], NULL, NULL, p);//���ڵ�
	circle(x, y, 25);
	setcolor(EGERGB(0xFF, 0xFF, 0x0));
	Sleep(1 * 1000);
	outtextxy(x, y, roottemp->data);
	Sleep(1 * 1000);
	if (flag) {}
	else line(x0, y0, x, y);
	Sleep(1 * 1000);
	p = roottemp;
	if (flag)
	{
		root = roottemp;
		flag = 0;
	}
	int r = 0;
	for (int i = 0; i < size; i++)
	{
		if (arrm[i] == roottemp->data)
		{
			r = i;
			break;
		}
	}

	roottemp->leftchild = creattreel(arrm, arrl, r, p, x, y, x / 2, y * 2);
	roottemp->rightchild = creattreel(arrm + 1 + r, arrl + r, size - 1 - r, p, x, y, (x / 2) * 3, y * 2);
	return roottemp;
}
void binarytree::preoder(bintreenode* p)
{
	if (p != NULL)
	{
		cout << p->data;
		preoder(p->leftchild);
		preoder(p->rightchild);
	}
}
void  binarytree::inoder(bintreenode* p)
{
	if (p != NULL)
	{
		inoder(p->leftchild);
		cout << p->data;
		inoder(p->rightchild);
	}
}
void  binarytree::postoder(bintreenode* p)
{
	if (p != NULL)
	{
		postoder(p->leftchild);
		postoder(p->rightchild);
		cout << p->data;
	}
}

int main()
{

	cout << "��ѡ����ǰ����������������1�����������������������2��" << endl;
	int b = 0;
	cin >> b;
	binarytree tree;
	if (b == 1)
	{
		cout << "������ǰ�����У�" << endl;
		cinarryp();
		cout << "�������������У�" << endl;
		cinarrym();
		whethererror(arrp, arrm, n);
		initgraph(640, 480);
		setcolor(GREEN);
		tree.creattreep(arrp, arrm, n, NULL, 0, 0, 320, 25);
	}
	else if (b == 2)
	{
		cout << "�������������У�" << endl;
		cinarrym();
		cout << "������������У�" << endl;
		cinarryl();
		whethererror(arrm, arrl, n);
		initgraph(640, 480);
		setcolor(GREEN);
		tree.creattreel(arrm, arrl, n, NULL, 0, 0, 320, 25);
	}
	cout << "������ǰ����������" << endl;
	tree.preoder(tree.root); cout << endl;
	cout << "������������������" << endl;
	tree.inoder(tree.root); cout << endl;
	cout << "������������������" << endl;
	tree.postoder(tree.root); cout << endl;

	getch();
	closegraph();
	/*system("pause");*/
	/*return 0;
}*/